<footer class="footer container-fluid py-3 text-center">
  <div class="mt-3">
    <img src="assets/logo.png" style="width:80px" alt="">
    <h3 class="foottitle ">OneIoT SmartFarm</h3>
    <p class="mx-auto col-5">SMKN 4 Bogor X-PPLG 2 group 1 Smart farm IOT project</p>
  </div>
  <div class="mt-3 d-flex flex-column">
    <h3 class="foottitle mx-auto">Navigation</h3>
    <a href="#home">Home</a>
    <a href="#about">About Us</a>
    <a href="#contact">Contact Us</a>
    <a href="#faq">FAQ</a>
  </div>
  <div class="mt-3">
    <h3 class="foottitle">Our Team</h3>
    <div class="con-team-footer">
      <p class="">Justine</p>
      <p class="">Ali Yasir Fauzan</p>
      <p class="">Ahmad Nur Khaaliq</p>
      <p class="">Rizky Febriansyah Pratama</p>
      <p class="">M. Bardan Sulaiman</p>
      <p class="">M. Pachmi Alkamil</p>
      <p class="">M. Sihab Budin</p>
      <p class="">M. Egi Syarif</p>
    </div>
  </div>
  <div class="mt-3">
    <i class="bi bi-geo-alt-fill"></i>
    <p class="m-0">South Bogor, West Java, Indonesia.</p>
    <i class="bi bi-whatsapp"></i>
    <p class="m-0">+6287774487198</p>
    <i class="bi bi-whatsapp"></i>
    <p class="m-0">+6282114201343</p>
    <i class="bi bi-envelope"></i>
    <p class="m-0">@zeruprogram@gmail.com</p>
  </div>
  <div class="mt-3 d-flex flex-column">
    <p>© 2024 One iot X PPLG 2. All right reversed. v1.0</p>
  </div>
</footer>